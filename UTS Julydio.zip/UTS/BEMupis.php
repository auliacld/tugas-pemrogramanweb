
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Tooplate">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>BEM UPI Serang</title>

    
   <!-- Additional CSS Files -->
  
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
  
   <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" type="text/css" href="assets/css/owl-carousel.css">

    <link rel ="stylesheet" href="assets/css/tooplate-artxibition.css">
    <link href="http://kd-serang.upi.edu/assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
 
<!--

Tooplate 2125 ArtXibition

https://www.tooplate.com/view/2125-artxibition

-->
    </head>
    
    <body>
    
    <!-- ***** Preloader Start ***** -->
    <div id="js-preloader" class="js-preloader">
      <div class="preloader-inner">
        <span class="dot"></span>
        <div class="dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->
    
    <!-- ***** Pre HEader ***** -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark" aria-label="Tenth navbar example">
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
    
          <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="BEMupis.php">Beranda</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Kajian</a>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled">Blog</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dropdown08" data-bs-toggle="dropdown" aria-expanded="false">Fungsionaris</a>
                <ul class="dropdown-menu" aria-labelledby="dropdown08">
                  <li><a class="dropdown-item" href="#">Departemen Pemberdayaan Sumber Daya Organisasi</a></li>
                  <li><a class="dropdown-item" href="#">Departemen Kewirausahaan dan Pengembangan Profesi</a></li>
                  <li><a class="dropdown-item" href="#">Departemen Sosial Politik</a></li>
                  <li><a class="dropdown-item" href="#">Departemen Departemen Komunikasi dan Informasi</a></li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled">Kontak</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    
    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="index.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                            <img src="http://kd-serang.upi.edu/assets/img/logo.png" class="img-fluid" width="120" alt=""> </img>
                            <span class="logo"><em>BEM</em> UPI Kampus Serang</span>
                          </a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <img class="bd-placeholder-img" width="100%" height="700px" img src="http://kd-serang.upi.edu/uploads/1608607914-WhatsApp%20Image%202020-12-21%20at%209.26.54%20PM(1).jpeg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></img>
    
    <div class="container px-4 py-5" id="featured-3">
        <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
          <div class="feature">
            <h2>Visi</h2>
            <p>Gerak serentak dalam mewujudkan kebermanfaatan untuk UPl dan negeri.</p>
          </div>
          <div class="feature">
            <h2>Misi</h2>
            <p>Kolam Harmoni</p>
            <p>Kolam Advokasi</p>
            <p>Kolam Aksi</p>
            <p>Kolam Prestasi</p>
            <p>Kolam Dedikasi</p>
          </div>
          <div class="feature">
            <h2>Tujuan</h2>
            <p>Membangun UPI Serang lebih baik</p>

          </div>
        </div>
      </div>

    <div class="venue-tickets">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading">
                        <h2>Blog</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="coming-events">
        <div class="left-button">
            <div class="main-white-button">
                <a href="shows-events.html">Selengkapnya</a>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="event-item">
                        <div class="thumb">
                            <a href="#"><img src="http://bem.rema.upi.edu/wp-content/uploads/2020/12/Komersialisasi-pendidikan.jpeg" alt=""></a>
                        </div>
                        <div class="down-content">
                            <a href="#"><h4>DAMPAK TERJADINYA KOMERSIALISASI PENDIDIKAN</h4></a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="event-item">
                        <div class="thumb">
                            <a href="#"><img src="http://bem.rema.upi.edu/wp-content/uploads/2020/12/dagri.jpg" alt=""></a>
                        </div>
                        <div class="down-content">
                            <a href="#"><h4>KOK KEKERASAN SEKSUAL BISA TERJADI DI KAMPUS ?</h4></a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="event-item">
                        <div class="thumb">
                            <a href="#"><img src="http://bem.rema.upi.edu/wp-content/uploads/2020/12/uang-600x342.jpg" alt=""></a>
                        </div>
                        <div class="down-content">
                            <a href="#"><h4>BENTUK-BENTUK LIBERASI PENDIDIKAN</h4></a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- *** Subscribe *** -->
    <div class="container py-4">
        <div class="row mb-3">
          <div class="col-md-8">
            <h2>Tanyakan Sesuatu</h2>
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Nama</label>
              <input type="text" class="form-control" placeholder="nama">
          </div>
          <div class="mb-3">
             
              <label for="exampleFormControlInput1" class="form-label">Email</label>
              <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">Pesan</label>
              <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
            <div class="mb-3">
              <button class="btn btn-primary">Kirim</button>
            </div>
          </div>
          <div class="col-md-4">
            <h2>Terhubung</h2> <br/>
            <h4>Find us at the office</h4>
            <p>Jl. Ciracas No.38, Serang, Kec. Serang, Kota Serang, Banten 42116 - Indonesia</p>
            
            <h4>Give us a ring</h4>
            <p>Call center:</p>
            <p>08989106935 Julydio</p>
             </div>
          </div>
        </div>
       </div>

    <!-- *** Footer *** -->
    <footer id="footer">

        <!----> <div class="footer-top">
          <div class="container">
            <div class="row">
    
              <div class="col-lg-3 col-md-6 footer-links">
                 <h4>FAKULTAS</h4>
                  <ul>
                  <li class="fa fa-external-link"> <a href="http://fip.upi.edu/" target="_blank">FIP</a></li>
                  <li class="fa fa-external-link"> <a href="http://fpips.upi.edu/" target="_blank">FPIPS</a></li>
                  <li class="fa fa-external-link"> <a href="http://fpbs.upi.edu/" target="_blank">FPBS</a></li>
                  <li class="fa fa-external-link"> <a href="http://fpmipa.upi.edu/" target="_blank">FPMIPA</a></li>
                  <li class="fa fa-external-link"> <a href="http://fptk.upi.edu/" target="_blank">FPTK</a></li>
                  <li class="fa fa-external-link"> <a href="http://fpok.upi.edu/" target="_blank">FPOK</a></li>
                  <li class="fa fa-external-link"> <a href="http://fpeb.upi.edu/" target="_blank">FPEB</a></li>
                  <li class="fa fa-external-link"> <a href="http://sps.upi.edu/" target="_blank">SPs</a></li>
                  </ul>
              </div>
    
              <div class="col-lg-3 col-md-6 footer-links">
                <h4>AKADEMIK</h4>
                <ul>
                  <li class="fa fa-external-link"> <a href="http://spot.upi.edu/" target="_blank" alt="E-Learning | Learning Management System | Sistem Pembelajaran Online Terpadu">SPOT</a></li>
                  <li class="fa fa-external-link"> <a href="http://mrs.upi.edu/" target="_blank" alt="Multimedia Resource Sharing">M R S</a></li>
                  <li class="fa fa-external-link"> <a href="http://sino.upi.edu/" target="_blank" alt="Sistem Informasi Nilai Online">S I N O</a> </li>
                  <li class="fa fa-external-link"> <a href="https://siak.upi.edu/sinndo/" target="_blank" title="Sistem Input Nilai Dosen">S I N N D O</a></li>
                  <li class="fa fa-external-link"> <a href="http://evaluasi-pbm.upi.edu/" target="_blank">Evaluasi PBM</a></li>
                  <li class="fa fa-external-link"> <a href="http://silabus.upi.edu/" target="_blank" alt="Silabus Perkuliahan">Silabus Online</a></li>
                  <li class="fa fa-external-link"> <a href="http://file.upi.edu/" target="_blank" alt="Direktori File">Direktori File</a></li>
    
                </ul>
              </div>
    
              <div class="col-lg-3 col-md-6 footer-links">
                <h4>RISET</h4>
                <ul>
                  <li class="fa fa-external-link"> <a href="http://jurnal.upi.edu/" target="_blank">Portal Jurnal</a></li>
                  <li class="fa fa-external-link"> <a href="http://bangdos.upi.edu/" target="_blank">Bangdos</a></li>
                  <li class="fa fa-external-link"><a href="http://penelitian.lppm.upi.edu/" target="_blank">Data Penelitian</a></li>
                  <li class="fa fa-external-link"> <a href="http://repository.upi.edu/" target="_blank">Repository</a></li>
                  <li class="fa fa-external-link"><a href="http://digilib.upi.edu/" target="_blank" alt="Digital Library">Digital Library</a></li>
                </ul>
              </div>
    
             <div class="col-lg-3 col-md-6 footer-links">
                <h4>WEB LINK</h4>
                  <ul>
                    <li class="fa fa-external-link"><a href="http://kd-cibiru.upi.edu" target="_blank" alt="Kampus Cibiru"> Kampus Cibiru</a></li>
                    <li class="fa fa-external-link"><a href="http://kd-tasikmalaya.upi.edu" target="_blank" alt="Kampus Tasikmalaya"> Kampus Tasikmalaya</a></li>
                    <li class="fa fa-external-link"><a href="http://kd-sumedang.upi.edu" target="_blank" alt="Kampus Sumedang"> Kampus Sumedang</a></li>
                    <li class="fa fa-external-link"><a href="http://kd-purwakarta.upi.edu" target="_blank" alt="Kampus Purwakarta"> Kampus Purwakarta</a></li>
                    <li class="fa fa-external-link"><a href="http://www.upi.edu" target="_blank" alt="Universitas"> Universitas</a></li>
                  </ul> 
              </div>
    
            </div>
          </div>
        </div>
    
        <div class="container d-md-flex py-4">
    
          <div class="mr-md-auto text-center text-md-left">
            <div class="copyright">
               <strong><span>UPI Kampus Serang</span></strong> @ 2020
            </div>
            <div class="credits">
            </div>
          </div>
      </footer>

    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/mixitup.js"></script> 
    <script src="assets/js/accordions.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>
    <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>

  </body>
</html>