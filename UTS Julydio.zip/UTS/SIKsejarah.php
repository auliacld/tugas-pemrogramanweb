<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Sejarah</title>
     <!-- Additional CSS Files -->
     <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

     <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
 
     <link rel="stylesheet" type="text/css" href="assets/css/owl-carousel.css">
 
     <link rel ="stylesheet" href="assets/css/tooplate-artxibition.css">
  <link href="http://kd-serang.upi.edu/assets/css/style.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
     
  </head>
  <body>
  <div class="container">
      <header class="d-flex flex-wrap justify-content-center py-3 mb-4">
        <a href="index.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
          <img src="http://kd-serang.upi.edu/assets/img/logo.png" class="img-fluid" width="120" alt=""> </img>
          <span class="fs-4"></span><b>Sistem Informasi Kelautan</b></span>
        </a>
  
        <ul class="nav nav-pills">
            <li class="nav-item"><a href="SIK.php" class="nav-link">Beranda</a></li>
            <div class="dropdown">
              <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color: blue">
                Akademik
              </button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="kurikulum.php">Kurikulum</a></li>
                <li><a class="dropdown-item" href="http://sik.kd-serang.upi.edu/?page_id=29">Laboratorium</a></li>
              </ul>
            </div>
            <li><div class="dropdown">
              <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color: blue">
                Profil
              </button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="SIKsejarah.php">Sejarah</a></li>
                <li><a class="dropdown-item" href="http://sik.kd-serang.upi.edu/?page_id=23">Visi Misi</a></li>
                <li><a class="dropdown-item" href="#">Struktur Organisasi</a></li>
                <li><a class="dropdown-item" href="http://sik.kd-serang.upi.edu/?page_id=27">Dosen</a></li>
              </ul>
            </li>
          <li class="nav-item"><a href="akreditasi.php" class="nav-link">Akreditasi</a></li>
          <li class="nav-item"><a href="galeri.php" class="nav-link">Galeri</a></li>
          <li class="nav-item"><a href="http://sik.kd-serang.upi.edu/?page_id=1666" class="nav-link">FAQ</a></li>
        </ul>
      </header>
    </div>


    <main>

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
      
        <ol>
            <li><a href="SIK.php">Home</a></li>
            <li><a href="SIK.php">Profil</a></li>
            <li class="active">Detail Profil</li>
        </ol>
        <h2>Profil - Sistem Informasi Kelautan </h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Blog Single Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-8 entries">

            <article class="entry entry-single">

             <!-- <div class="entry-img">
                <img class="img-fluid" width="100%" src="http://kd-serang.upi.edu/uploads/1598757182-hero-bg.jpg">
              </div> -->

              <h2 class="entry-title">
                <a href="SIKsejarah.html">Sejarah Sistem Informasi Kelautan </a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="#">Posted on 2020-08-30 03:13:04</a></li>
                </ul>
              </div>

              <div class="entry-content">
                 
                <!-- Post Content -->
                <p>Universitas Pendidikan Indonesia (UPI) sebagai universitas pelopor dan unggul perlu berkontribusi dalam bidang tersebut dan juga dalam rangka UPI sebagai Center of Excellence bidang Pendidikan Vokasi. Kemudian, dalam rangka mempersiapkan sumberdaya manusia sektor kemaritiman pada era revolusi industri 4.0 UPI pada tahun 2019 berencana membuka program studi Sistem Informasi Kelautan. Sistem Informasi Kelautan merupakan bagian dari Ilmu Kelautan yang fokus pada analisis data kelautan baik numerik maupun spasial untuk kemudian diintegrasikan ke dalam suatu sistem informasi yang dikembangkan sebagai dasar pengambilan keputusan. Sumberdaya manusia yang terampil dalam hal tersebut sangat diperlukan dalam pembangunan di sektor kemaritiman pada industri 4.0.</p>
              </div>


                <div class="float-right share">
                  <a href="" title="Share on Twitter"><i class="icofont-twitter"></i></a>
                  <a href="" title="Share on Facebook"><i class="icofont-facebook"></i></a>
                  <a href="" title="Share on Instagram"><i class="icofont-instagram"></i></a>
                </div>

              </div>

            </article><!-- End blog entry -->

           </div><!-- End blog entries list -->

          </div><!-- End blog sidebar -->

        </div>

      </div>
    </section><!-- End Blog Single Section -->

  </main>

    </main>

    <footer id="footer">

      <!----> <div class="footer-top">
        <div class="container">
          <div class="row">
  
            <div class="col-lg-3 col-md-6 footer-links">
               <h4>FAKULTAS</h4>
                <ul>
                <li class="fa fa-external-link"> <a href="http://fip.upi.edu/" target="_blank">FIP</a></li>
                <li class="fa fa-external-link"> <a href="http://fpips.upi.edu/" target="_blank">FPIPS</a></li>
                <li class="fa fa-external-link"> <a href="http://fpbs.upi.edu/" target="_blank">FPBS</a></li>
                <li class="fa fa-external-link"> <a href="http://fpmipa.upi.edu/" target="_blank">FPMIPA</a></li>
                <li class="fa fa-external-link"> <a href="http://fptk.upi.edu/" target="_blank">FPTK</a></li>
                <li class="fa fa-external-link"> <a href="http://fpok.upi.edu/" target="_blank">FPOK</a></li>
                <li class="fa fa-external-link"> <a href="http://fpeb.upi.edu/" target="_blank">FPEB</a></li>
                <li class="fa fa-external-link"> <a href="http://sps.upi.edu/" target="_blank">SPs</a></li>
                </ul>
            </div>
  
            <div class="col-lg-3 col-md-6 footer-links">
              <h4>AKADEMIK</h4>
              <ul>
                <li class="fa fa-external-link"> <a href="http://spot.upi.edu/" target="_blank" alt="E-Learning | Learning Management System | Sistem Pembelajaran Online Terpadu">SPOT</a></li>
                <li class="fa fa-external-link"> <a href="http://mrs.upi.edu/" target="_blank" alt="Multimedia Resource Sharing">M R S</a></li>
                <li class="fa fa-external-link"> <a href="http://sino.upi.edu/" target="_blank" alt="Sistem Informasi Nilai Online">S I N O</a> </li>
                <li class="fa fa-external-link"> <a href="https://siak.upi.edu/sinndo/" target="_blank" title="Sistem Input Nilai Dosen">S I N N D O</a></li>
                <li class="fa fa-external-link"> <a href="http://evaluasi-pbm.upi.edu/" target="_blank">Evaluasi PBM</a></li>
                <li class="fa fa-external-link"> <a href="http://silabus.upi.edu/" target="_blank" alt="Silabus Perkuliahan">Silabus Online</a></li>
                <li class="fa fa-external-link"> <a href="http://file.upi.edu/" target="_blank" alt="Direktori File">Direktori File</a></li>
  
              </ul>
            </div>
  
            <div class="col-lg-3 col-md-6 footer-links">
              <h4>RISET</h4>
              <ul>
                <li class="fa fa-external-link"> <a href="http://jurnal.upi.edu/" target="_blank">Portal Jurnal</a></li>
                <li class="fa fa-external-link"> <a href="http://bangdos.upi.edu/" target="_blank">Bangdos</a></li>
                <li class="fa fa-external-link"><a href="http://penelitian.lppm.upi.edu/" target="_blank">Data Penelitian</a></li>
                <li class="fa fa-external-link"> <a href="http://repository.upi.edu/" target="_blank">Repository</a></li>
                <li class="fa fa-external-link"><a href="http://digilib.upi.edu/" target="_blank" alt="Digital Library">Digital Library</a></li>
              </ul>
            </div>
  
           <div class="col-lg-3 col-md-6 footer-links">
              <h4>WEB LINK</h4>
                <ul>
                  <li class="fa fa-external-link"><a href="http://kd-cibiru.upi.edu" target="_blank" alt="Kampus Cibiru"> Kampus Cibiru</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-tasikmalaya.upi.edu" target="_blank" alt="Kampus Tasikmalaya"> Kampus Tasikmalaya</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-sumedang.upi.edu" target="_blank" alt="Kampus Sumedang"> Kampus Sumedang</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-purwakarta.upi.edu" target="_blank" alt="Kampus Purwakarta"> Kampus Purwakarta</a></li>
                  <li class="fa fa-external-link"><a href="http://www.upi.edu" target="_blank" alt="Universitas"> Universitas</a></li>
                </ul> 
            </div>
  
          </div>
        </div>
      </div>
  
      <div class="container d-md-flex py-4">
  
        <div class="mr-md-auto text-center text-md-left">
          <div class="copyright">
             <strong><span>UPI Kampus Serang</span></strong> @ 2020
          </div>
          <div class="credits">
          </div>
        </div>
    </footer>

    <script src="http://kd-serang.upi.edu/assets/vendor/jquery/jquery.min.js"></script>
    <script src="http://kd-serang.upi.edu/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="http://kd-serang.upi.edu/assets/js/main.js"></script>
      <script src="assets/js/owl-carousel.js"></script>
      
      <!-- Global Init -->
      <script src="assets/js/custom.js"></script>
  </body>
 
 
</html>