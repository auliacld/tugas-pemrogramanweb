<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Home</title>
       <!-- Additional CSS Files -->
       <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

       <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
   
       <link rel="stylesheet" type="text/css" href="assets/css/owl-carousel.css">
   
       <link rel ="stylesheet" href="assets/css/tooplate-artxibition.css">
    <link href="http://kd-serang.upi.edu/assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
 
 <style>
      header {
          background-color: red;
          font-family: montserrat;
    }
  </style>
</head>
  <body>
    <div class="container">
      <header class="d-flex flex-wrap justify-content-center py-3 mb-4 container-fluid">
        <div class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-light text-decoration-none">
        <a href="http://www.upi.edu" >
            <img src="https://www.upi.edu/images/upi-logo-2.png" class="img-fluid" width="120" alt="">
        </a>
          <span class="fs-4"></span></b>Kampus Serang</span>
        </div>
    
        <ul class="nav nav-pills">
            <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
            <li class="nav-item"><a href="#berita" class="nav-link">Berita</a></li>
            <div class="dropdown">
              <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color:white">
                Profil
              </button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="sejarah.php">Sejarah</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/profile/17">Visi Misi</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/profile/18">Program Kerja</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/listdosen">Dosen</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/listpegawai">Staff</a></li>
              </ul>
            </div>
          <div class="dropdown">
            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color:white">
              Program Studi
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="SIK.php">Sistem Informasi Kelautan</a></li>
              <li><a class="dropdown-item" href="http://pkp.kd-serang.upi.edu/">Pendidikan Kelautan Perikanan</a></li>
              <li><a class="dropdown-item" href="http://logkel.kd-serang.upi.edu/">Logistik Kelautan</a></li>
              <li><a class="dropdown-item" href="http://pgsd-serang.upi.edu/">PGSD</a></li>
              <li><a class="dropdown-item" href="http://pgpaud-serang.upi.edu/">PGPAUD</a></li>
            </ul>
          </div>
          <li class="nav-item"><a href="#fasilitas" class="nav-link">Fasilitas</a></li>
          <div class="dropdown">
            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color:white">
              Organisasi Mahasiswa
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="BEMupis.php">BEM UPI Serang</a></li>
              <li><a class="dropdown-item" href="#">DPM UPI Serang</a></li>
              <li><a class="dropdown-item" href="#">UKM KPM</a></li>
              <li><a class="dropdown-item" href="#">UKM ANZNI</a></li>
              <li><a class="dropdown-item" href="#">UKM PORMAPI</a></li>
              <li><a class="dropdown-item" href="#">UKM PORMAPI</a></li>
            </ul>
          </div>
          <li class="nav-item"><a href="#" class="nav-link">FAQ</a></li>
        </ul>
      </header>
  </div>

<main>
  <img class="bd-placeholder-img" width="100%" height="700px" img src="http://kd-serang.upi.edu/uploads/1608607914-WhatsApp%20Image%202020-12-21%20at%209.26.54%20PM(1).jpeg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></img>
  <div class="container col-xxl-8 px-4 py-5">
    <div data-aos="fade-up">
      <div class="section-title">
        <h2>UPI KAMPUS SERANG</h2>
      </div>
    <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
      <div class="col-10 col-sm-8 col-lg-6">
        <img src="http://kd-serang.upi.edu/uploads/1608607914-WhatsApp%20Image%202020-12-21%20at%209.26.54%20PM(1).jpeg" class="d-block mx-lg-auto img-fluid" alt="Bootstrap Themes" width="500" height=200" loading="lazy">
      </div>
      <div class="col-lg-6">
        <p class="lead">UPI Kampus Serang merupakan kampus terintegrasi dengan kampus induk UPI di Bandung. Hal ini sesuai dengan UU No 15 Tahun 2014 tentang Statuta UPI. Karena menganut azas kesatuan maka antara kampus induk dan daerah bermakna adanya kesatuan akademik dan manajemen, sehingga UPI Kampus Serang bukan kampus jauh, namun kampus UPI yang berlokasi di daerah Serang.
UPI Kampus Serang merupakan salah satu multi kampus di Universitas Pendidikan Indonesia. Peran multi kampus adalah merupakan satelit bagi kampus induk . UPI Kampus Serang mengimplementasikan ketercapain visi dan misi universitas, namun secara mikro hal tersebut diimplementasikan sesuai dengan perkembangan budaya dan konteks kedaerahan.</p>
      </div>
    </div>
  </div>
  </div>

    <div class="section-title">
      <h2>Papan Informasi</h2>
    </div>

  <div id="myCarousel" class="carousel slide" data-bs-ride="carousel ">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="bd-placeholder-img" width="100%" height="580px" img src="http://kd-serang.upi.edu/uploads/1635835833-informasi10.jpg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></img>
            <div class="container">
              <div class="carousel-caption text-start">
                <p><a class="btn btn-lg btn-primary" href="http://dit-akademik.upi.edu/"">Selengkapnya</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img class="bd-placeholder-img" width="100%" height="580px" img src="http://kd-serang.upi.edu/uploads/1635834346-WhatsApp Image 2021-10-27 at 8.03.06 AM.jpeg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></img>
            <div class="container">
              <div class="carousel-caption ">
                <p><a class="btn btn-lg btn-primary" href="http://dit-akademik.upi.edu/index.php/2021/10/19/daftar-mahasiswa-upi-angkatan-2021-yang-belum-melengkapi-data-diri/">Selengkapnya</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img class="bd-placeholder-img" width="100%" height="580px" img src="http://kd-serang.upi.edu/uploads/1634804681-informasi10.jpg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></img>
            <div class="container">
              <div class="carousel-caption text-end">
               <p><a class="btn btn-lg btn-primary" href="http://dit-pendidikan.upi.edu/">Selengkapnya</a></p>
              </div>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>

      <div id="fasilitas" class="fasilitas container" data-aos="fade-up">
        <div class="section-title">
          <h2><br>Fasilitas</h2>
        </div>
      </div>
      <br> <br>
      <div class="show-events-carousel">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="owl-show-events owl-carousel">
                        <div class="item">
                            <img src="http://kd-serang.upi.edu/uploads/1608609267-WhatsApp%20Image%202020-11-18%20at%207.55.29%20AM.jpeg" alt="">
                            <h4 class="text-center">Lab Komputer</h4>
                        </div>
                        <div class="item">
                            <img src="http://kd-serang.upi.edu/uploads/1617075106-2021-03-23,%2010%2055%2043%20AM.jpeg" alt="">
                            <h4 class="text-center">Gedung Baru</h4>
                          </div>
                        <div class="item"> 
                            <img src="http://kd-serang.upi.edu/uploads/1608607914-WhatsApp%20Image%202020-12-21%20at%209.26.54%20PM(1).jpeg" alt="">
                            <h4 class="text-center">Gedung Administrasi</h4>
                       </div>
                        <div class="item">
                            <img src="http://kd-serang.upi.edu/uploads/1601279097-WhatsApp%20Image%202020-09-28%20at%202.40-tile.jpg" alt="">
                            <h4 class="text-center">Marine Station</h4>
                          </div>
                       <div class="item">
                          <img src="http://pkp.kd-serang.upi.edu/wp-content/uploads/2021/04/1619161695-FotoJet-3.jpg" alt="">
                           <h4 class="text-center">Lab Budidaya</h4>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <hr>

    <div class="container py-4">
      <div class="row mb-3">
        <div class="col-md-4">
          <h2>Tanyakan Sesuatu</h2>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Nama</label>
            <input type="text" class="form-control" placeholder="nama">
        </div>
        <div class="mb-3">
           
            <label for="exampleFormControlInput1" class="form-label">Email</label>
            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
          </div>
          <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Pesan</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
          </div>
          <div class="mb-3">
            <button class="btn btn-primary">Kirim</button>
          </div>
        </div>
        <div class="col-md-8">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3967.0370422558185!2d106.14447451430932!3d-6.125717661768984!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e418adaa4f7f563%3A0x950ec58123df8596!2sUniversitas%20Pendidikan%20Indonesia%20(UPI)%20Kampus%20Serang!5e0!3m2!1sen!2sid!4v1633688548832!5m2!1sen!2sid" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
        </div>
      </div>
     </div>

    <footer id="footer">

      <!----> <div class="footer-top">
        <div class="container">
          <div class="row">
  
            <div class="col-lg-3 col-md-6 footer-links">
               <h4>FAKULTAS</h4>
                <ul>
                <li class="fa fa-external-link"> <a href="http://fip.upi.edu/" target="_blank">FIP</a></li>
                <li class="fa fa-external-link"> <a href="http://fpips.upi.edu/" target="_blank">FPIPS</a></li>
                <li class="fa fa-external-link"> <a href="http://fpbs.upi.edu/" target="_blank">FPBS</a></li>
                <li class="fa fa-external-link"> <a href="http://fpmipa.upi.edu/" target="_blank">FPMIPA</a></li>
                <li class="fa fa-external-link"> <a href="http://fptk.upi.edu/" target="_blank">FPTK</a></li>
                <li class="fa fa-external-link"> <a href="http://fpok.upi.edu/" target="_blank">FPOK</a></li>
                <li class="fa fa-external-link"> <a href="http://fpeb.upi.edu/" target="_blank">FPEB</a></li>
                <li class="fa fa-external-link"> <a href="http://sps.upi.edu/" target="_blank">SPs</a></li>
                </ul>
            </div>
  
            <div class="col-lg-3 col-md-6 footer-links">
              <h4>AKADEMIK</h4>
              <ul>
                <li class="fa fa-external-link"> <a href="http://spot.upi.edu/" target="_blank" alt="E-Learning | Learning Management System | Sistem Pembelajaran Online Terpadu">SPOT</a></li>
                <li class="fa fa-external-link"> <a href="http://mrs.upi.edu/" target="_blank" alt="Multimedia Resource Sharing">M R S</a></li>
                <li class="fa fa-external-link"> <a href="http://sino.upi.edu/" target="_blank" alt="Sistem Informasi Nilai Online">S I N O</a> </li>
                <li class="fa fa-external-link"> <a href="https://siak.upi.edu/sinndo/" target="_blank" title="Sistem Input Nilai Dosen">S I N N D O</a></li>
                <li class="fa fa-external-link"> <a href="http://evaluasi-pbm.upi.edu/" target="_blank">Evaluasi PBM</a></li>
                <li class="fa fa-external-link"> <a href="http://silabus.upi.edu/" target="_blank" alt="Silabus Perkuliahan">Silabus Online</a></li>
                <li class="fa fa-external-link"> <a href="http://file.upi.edu/" target="_blank" alt="Direktori File">Direktori File</a></li>
  
              </ul>
            </div>
  
            <div class="col-lg-3 col-md-6 footer-links">
              <h4>RISET</h4>
              <ul>
                <li class="fa fa-external-link"> <a href="http://jurnal.upi.edu/" target="_blank">Portal Jurnal</a></li>
                <li class="fa fa-external-link"> <a href="http://bangdos.upi.edu/" target="_blank">Bangdos</a></li>
                <li class="fa fa-external-link"><a href="http://penelitian.lppm.upi.edu/" target="_blank">Data Penelitian</a></li>
                <li class="fa fa-external-link"> <a href="http://repository.upi.edu/" target="_blank">Repository</a></li>
                <li class="fa fa-external-link"><a href="http://digilib.upi.edu/" target="_blank" alt="Digital Library">Digital Library</a></li>
              </ul>
            </div>
  
           <div class="col-lg-3 col-md-6 footer-links">
              <h4>WEB LINK</h4>
                <ul>
                  <li class="fa fa-external-link"><a href="http://kd-cibiru.upi.edu" target="_blank" alt="Kampus Cibiru"> Kampus Cibiru</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-tasikmalaya.upi.edu" target="_blank" alt="Kampus Tasikmalaya"> Kampus Tasikmalaya</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-sumedang.upi.edu" target="_blank" alt="Kampus Sumedang"> Kampus Sumedang</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-purwakarta.upi.edu" target="_blank" alt="Kampus Purwakarta"> Kampus Purwakarta</a></li>
                  <li class="fa fa-external-link"><a href="http://www.upi.edu" target="_blank" alt="Universitas"> Universitas</a></li>
                </ul> 
            </div>
  
          </div>
        </div>
      </div>
  
      <div class="container d-md-flex py-4">
  
        <div class="mr-md-auto text-center text-md-left">
          <div class="copyright">
             <strong><span>UPI Kampus Serang</span></strong> @ 2020
          </div>
          <div class="credits">
          </div>
        </div>
    </footer>
    </main>
    <script src="http://kd-serang.upi.edu/assets/vendor/jquery/jquery.min.js"></script>
  <script src="http://kd-serang.upi.edu/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="http://kd-serang.upi.edu/assets/js/main.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

  </body>
    
 
</html>