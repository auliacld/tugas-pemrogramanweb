<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Home</title>
       <!-- Additional CSS Files -->
       <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

       <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
   
       <link rel="stylesheet" type="text/css" href="assets/css/owl-carousel.css">
   
       <link rel ="stylesheet" href="assets/css/tooplate-artxibition.css">
    <link href="http://kd-serang.upi.edu/assets/css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
 
 <style>
      header {
          background-color: red;
          font-family: montserrat;
    }
  </style>
</head>
  <body>
  <header class="d-flex flex-wrap justify-content-center py-3 mb-4 container-fluid">
        <div class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-light text-decoration-none">
        <a href="http://www.upi.edu" >
            <img src="https://www.upi.edu/images/upi-logo-2.png" class="img-fluid" width="120" alt="">
        </a>
          <span class="fs-4"></span></b>Kampus Serang</span>
        </div>
    
        <ul class="nav nav-pills">
            <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
            <li class="nav-item"><a href="#berita" class="nav-link">Berita</a></li>
            <div class="dropdown">
              <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color:white">
                Profil
              </button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="sejarah.php">Sejarah</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/profile/17">Visi Misi</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/profile/18">Program Kerja</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/listdosen">Dosen</a></li>
                <li><a class="dropdown-item" href="http://kd-serang.upi.edu/listpegawai">Staff</a></li>
              </ul>
            </div>
          <div class="dropdown">
            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color:white">
              Program Studi
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="SIK.php">Sistem Informasi Kelautan</a></li>
              <li><a class="dropdown-item" href="http://pkp.kd-serang.upi.edu/">Pendidikan Kelautan Perikanan</a></li>
              <li><a class="dropdown-item" href="http://logkel.kd-serang.upi.edu/">Logistik Kelautan</a></li>
              <li><a class="dropdown-item" href="http://pgsd-serang.upi.edu/">PGSD</a></li>
              <li><a class="dropdown-item" href="http://pgpaud-serang.upi.edu/">PGPAUD</a></li>
            </ul>
          </div>
          <li class="nav-item"><a href="#fasilitas" class="nav-link">Fasilitas</a></li>
          <div class="dropdown">
            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color:white">
              Organisasi Mahasiswa
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="BEMupis.php">BEM UPI Serang</a></li>
              <li><a class="dropdown-item" href="#">DPM UPI Serang</a></li>
              <li><a class="dropdown-item" href="#">UKM KPM</a></li>
              <li><a class="dropdown-item" href="#">UKM ANZNI</a></li>
              <li><a class="dropdown-item" href="#">UKM PORMAPI</a></li>
              <li><a class="dropdown-item" href="#">UKM PORMAPI</a></li>
            </ul>
          </div>
          <li class="nav-item"><a href="#" class="nav-link">FAQ</a></li>
        </ul>
      </header>
      <main></main>

        <!-- ======= Breadcrumbs ======= -->
        <section class="breadcrumbs">
          <div class="container">
          
            <ol>
                <li><a href="main.html">Home</a></li>
                <li><a href="main.html">Profil</a></li>
                <li class="active">Detail Profil</li>
            </ol>
            <h2>Profil - UPI Kampus Serang </h2>
    
          </div>
        </section><!-- End Breadcrumbs -->
    
        <!-- ======= Blog Single Section ======= -->
        <section id="blog" class="blog">
          <div class="container" data-aos="fade-up">
    
            <div class="row">
    
              <div class="col-lg-8 entries">
    
                <article class="entry entry-single">
    
                 <!-- <div class="entry-img">
                    <img class="img-fluid" width="100%" src="http://kd-serang.upi.edu/uploads/1598757182-hero-bg.jpg">
                  </div> -->
    
                  <h2 class="entry-title">
                    <a href="#">Sejarah UPI Kampus Serang </a>
                  </h2>
    
                  <div class="entry-meta">
                    <ul>
                      <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="#">Posted on 2020-08-30 03:13:04</a></li>
                    </ul>
                  </div>
    
                  <div class="entry-content">
                     
                    <!-- Post Content -->
                    
                    
                      <p>Kehadiran Universitas Pendidikan Indonesia (UPI) di Serang, karena adanya sosok Sekolah Pendidikan Guru (SPG) Negeri Serang, yang berkedudukan di Jl. Ciracas No.18 Kel. /Kec. /Kab. Serang &ndash; Provinsi Banten. SPG Negeri Serang, sebelumnya berkedudukan di Jl. Ki Mas Jong No: 5 Kelurahan Kotabaru, Kec./Kab. Serang &ndash; Provinsi Jawa Barat. SPGN Serang dibangun di atas tanah seluas l.k. 4.000 m2 . Selain itu SPG Negeri Serang memiliki Asrama dan Rumah Dinas Kepala Sekolah (Sekarang Kantor Pejuang 45 dan Sekolah TK Pertiwi) yang berkedudukan di Jl. Ki Mas Jong l.k. 500 meter dari gedung pusat belajar SPG Negeri Serang.<br />
    <br />
    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; Pada tahun 1980 SPG Negeri Serang pindah ke gedung baru yang berkedudukan di Jl. Ciracas No.18 Kel. /Kec. /Kab. Serang &ndash; Provinsi Jawa Barat. Saat itu SPG Negeri Serang dibangun di atas tanah seluas l.k. 4.5 ha, yang meliputi unit bangunan ruang belajar, micro teaching, perpustakaan, laboratorium IPA, pusat kegiatan OSIS, kantor tata usaha, ruang guru dan ruang kepala sekolah, ruang kesenian dan olah raga, kantin dan ruang fasilitas lainnya.<br />
    <br />
    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; Sekolah Pendidikan Guru (SPG) mempunyai Misi &ldquo;menghasilkan calon-calon guru SD dan guru TK&rdquo; dengan lama pendidikan tiga tahun. Rekrutmen siswa SPG adalah mereka lulusan SLP yang disaring melalui tes tertulis dan wawancara keminatan. Lulusan SPG berwewenang mengajar di SD dan TK sesuai SK Pengangkatan CPNS yang dikeluarkan oleh Kanwil Dedikbud Dirjen Dikdasmen (Pedoman Penyelenggaraan SPG, 1976: 5).<br />
    <br />
    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; Berdasarkan SK Mendikbud No. 0854 /O /1989 tanggal: 30 Desember 1989 dan SK Dirjen Dikti No.178&ndash;Dikti/ Kep /1990 tanggal: 16 April 1990. SPG / SGO dan SGPLB ditingkatkan kualifikasinya menjadi program Diploma II Pendidikan Guru Sekolah Dasar (PGSD). Namun dalam kenyataan hanya sebagian saja yang ditetapkan dan dialih-fungsikan pemerintah, termasuk diantaranya Ex SPG Negeri Serang sebagai UPP (Unit Pelaksana Pendidikan) Diploma II PGSD Kab.Serang. Ex&ndash;SPG Negeri Serang, baru resmi alih fungsi menjadi UPP (Unit Pelaksana Pendidikan) Diploma II PGSD pada tahun 1991 setelah Ex-SPG Negeri Cibiru, Purwakarta, Tasikmalaya, dan Sumedang, yang diresmikan pada tahun 1990 (lebih dulu dari Ex-SPG Negeri Serang). Sebagai Unit Pelaksana Pendidikan atau UPP PGSD Serang ini, secara Struktur Organisasi Kelembagaan, diatur oleh Fakultas Ilmu Penddikan, Institut Keguruan dan Ilmu Pendidikan ( FIP &ndash; IKIP ) Bandung. Pada awal perkembangannya (1991) UPP PGSD Serang menerima sebanyak 80 orang mahasiswa (2 Kelas) untuk Program D2 PGSD yang direkrut melalui saringan Penerimaan Mahasiswa Jalur Khusus (PMJK) IKIP Bandung. Secara keseluruhan rekrutmen mahasiswa tersebut 80 % berasal dari latar belakang pendidikan SPG dan 20 % berasal dari latar belakang pendidikan PGA dan SGO. Mahasiswa yang diterima pada Program Studi D2 PGSD, diberi tunjangan Beasiswa Ikatan Dinas dan jaminan kerja sebagai CPNS Guru Sekolah Dasar. Hal ini dapat dilakukan atas dasar kerjasama IKIP Bandung dengan pihak Kanwil Depdikbud Provinsi Jawa Barat. Pada posisi UPP PGSD Serang saat itu, mampu membangkitkan kesadaran masyarakat akan pentingnya pendidikan, sehingga banyak permintaan pemerintah daerah agar UPP PGSD memperhtikan masyarakat akan kebutuhan tenaga guru dan pemerataan pendidikan untuk masyarakat Banten khususnya.<br />
    <br />
    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; Pada tahun 2000 IKIP Bndung berubah status menjadi Universitas. Hal ini dilandasi oleh Keputuran Presiden R.I. No.124 / 1999 tanggal: 7 Oktober 1999. Dengan perubahan status IKIP menjadi UPI, membawa implikasi terhadap perubahan Visi &ndash; Misi dan Tujuan kelembagaan. Melalui perubahan status, UPI membuka berbagai disiplin ilmu, teknologi, dan seni, baik berupa kependidikan maupun non-kependidikan. Merespon kebutuhan akan pentingnya kualitas tenaga kependidikan di daerah, maka pada tahun 2002 UPI secara resmi mengubah status UPP menjadi UPI Kampus Daerah (SK Rektor No.11745 /J 33 /KL.02.04 /1992) yang merupakan bagian terpadu dari sistem manajemen multikampus UPI. Fungsi utama penyelenggaraan Program D2 / S1 PGSD serta program-program lain yang sangat diperlukan di daerah yang dalam penyelenggaraannya terkait ketersediaan sumber daya manusia dan prasarana yang memenuhi standar di UPI. Membuka program di UPI Kampus Serang diberlakukan berdasarkan kebutuhan daerah, ketersediaan tenaga, dan sifatnya on &ndash; of .<br />
    <br />
    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; Sejarah perkembangan UPI Kamus Serang saat ini, menujukkan bahwa lembaga ini sangat responsif terhadap tuntutan masyarakat dan perkembangan dunia pendidikan tinggi di Indonesia. Perubahan status kelembagaan yang terjadi memberikan pengalaman dan kemampuan adaptasi yang tinggi terhadap perubahan dan kesetiaan &ldquo;Misi&rdquo; utama yang ditetapkan pada awal pendirian. Dengan sifatnya yang demikian, pengembangan status Universitas menjadi Universitas berstatus Badan Hukum Milik Negara (UPI BHMN) memberikan tantangan baru untuk berkembang dan menempatkan diri sebagai Universitas Pelopor dalam Bidang Kependidikan. Dinamika kelembagaan yang ditunjukkan dalam perubahan tersebut adalah menempatkan UPI sebagai Lembaga Pendidikan Tinggi yang selalu siap berubah, dan perubahan adalah kesempatan baru untuk maju ke arah yang lebih baik lagi.</p>
                    
                  
                  </div>
    
                  <div class="entry-footer clearfix">
                    <div class="float-left">
                      <i class="icofont-folder"></i>
                      <ul class="cats">
                        <li><a href="#">Profil kampus</a></li>
                      </ul>
    
                      <i class="icofont-tags"></i>
                      <ul class="tags">
                        <li><a href="#">Upi Kampus Serang</a></li>
                      </ul>
                    </div>
    
                    <div class="float-right share">
                      <a href="" title="Share on Twitter"><i class="icofont-twitter"></i></a>
                      <a href="" title="Share on Facebook"><i class="icofont-facebook"></i></a>
                      <a href="" title="Share on Instagram"><i class="icofont-instagram"></i></a>
                    </div>
    
                  </div>
    
                </article><!-- End blog entry -->
    
               </div><!-- End blog entries list -->
    
              <div class="col-lg-4">
    
                <div class="sidebar">
    
                 
    
                 
                  <h3 class="sidebar-title">Profil Kampus</h3>
                  <div class="sidebar-item recent-posts">
                                    <div class="post-item clearfix">
                      <a href="15">Sejarah UPI Kampus Serang</a>
                    </div>
    
                                    <div class="post-item clearfix">
                      <a href="16">Kata Sambutan Direktur UPI Kampus Serang</a>
                    </div>
    
                                    <div class="post-item clearfix">
                      <a href="17">Visi dan Misi - UPI Kampus Serang</a>
                    </div>
    
                                    <div class="post-item clearfix">
                      <a href="18">Program Kerja</a>
                    </div>
    
                    
                  
                  </div><!-- End sidebar recent posts-->
    
                 
                </div><!-- End sidebar -->
    
              </div><!-- End blog sidebar -->
    
            </div>
    
          </div>
        </section><!-- End Blog Single Section -->
    
      </main>
     <!-- ======= Footer ======= -->
    <footer id="footer">

      <!----> <div class="footer-top">
        <div class="container">
          <div class="row">
  
            <div class="col-lg-3 col-md-6 footer-links">
               <h4>FAKULTAS</h4>
                <ul>
                <li class="fa fa-external-link"> <a href="http://fip.upi.edu/" target="_blank">FIP</a></li>
                <li class="fa fa-external-link"> <a href="http://fpips.upi.edu/" target="_blank">FPIPS</a></li>
                <li class="fa fa-external-link"> <a href="http://fpbs.upi.edu/" target="_blank">FPBS</a></li>
                <li class="fa fa-external-link"> <a href="http://fpmipa.upi.edu/" target="_blank">FPMIPA</a></li>
                <li class="fa fa-external-link"> <a href="http://fptk.upi.edu/" target="_blank">FPTK</a></li>
                <li class="fa fa-external-link"> <a href="http://fpok.upi.edu/" target="_blank">FPOK</a></li>
                <li class="fa fa-external-link"> <a href="http://fpeb.upi.edu/" target="_blank">FPEB</a></li>
                <li class="fa fa-external-link"> <a href="http://sps.upi.edu/" target="_blank">SPs</a></li>
                </ul>
            </div>
  
            <div class="col-lg-3 col-md-6 footer-links">
              <h4>AKADEMIK</h4>
              <ul>
                <li class="fa fa-external-link"> <a href="http://spot.upi.edu/" target="_blank" alt="E-Learning | Learning Management System | Sistem Pembelajaran Online Terpadu">SPOT</a></li>
                <li class="fa fa-external-link"> <a href="http://mrs.upi.edu/" target="_blank" alt="Multimedia Resource Sharing">M R S</a></li>
                <li class="fa fa-external-link"> <a href="http://sino.upi.edu/" target="_blank" alt="Sistem Informasi Nilai Online">S I N O</a> </li>
                <li class="fa fa-external-link"> <a href="https://siak.upi.edu/sinndo/" target="_blank" title="Sistem Input Nilai Dosen">S I N N D O</a></li>
                <li class="fa fa-external-link"> <a href="http://evaluasi-pbm.upi.edu/" target="_blank">Evaluasi PBM</a></li>
                <li class="fa fa-external-link"> <a href="http://silabus.upi.edu/" target="_blank" alt="Silabus Perkuliahan">Silabus Online</a></li>
                <li class="fa fa-external-link"> <a href="http://file.upi.edu/" target="_blank" alt="Direktori File">Direktori File</a></li>
  
              </ul>
            </div>
  
            <div class="col-lg-3 col-md-6 footer-links">
              <h4>RISET</h4>
              <ul>
                <li class="fa fa-external-link"> <a href="http://jurnal.upi.edu/" target="_blank">Portal Jurnal</a></li>
                <li class="fa fa-external-link"> <a href="http://bangdos.upi.edu/" target="_blank">Bangdos</a></li>
                <li class="fa fa-external-link"><a href="http://penelitian.lppm.upi.edu/" target="_blank">Data Penelitian</a></li>
                <li class="fa fa-external-link"> <a href="http://repository.upi.edu/" target="_blank">Repository</a></li>
                <li class="fa fa-external-link"><a href="http://digilib.upi.edu/" target="_blank" alt="Digital Library">Digital Library</a></li>
              </ul>
            </div>
  
           <div class="col-lg-3 col-md-6 footer-links">
              <h4>WEB LINK</h4>
                <ul>
                  <li class="fa fa-external-link"><a href="http://kd-cibiru.upi.edu" target="_blank" alt="Kampus Cibiru"> Kampus Cibiru</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-tasikmalaya.upi.edu" target="_blank" alt="Kampus Tasikmalaya"> Kampus Tasikmalaya</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-sumedang.upi.edu" target="_blank" alt="Kampus Sumedang"> Kampus Sumedang</a></li>
                  <li class="fa fa-external-link"><a href="http://kd-purwakarta.upi.edu" target="_blank" alt="Kampus Purwakarta"> Kampus Purwakarta</a></li>
                  <li class="fa fa-external-link"><a href="http://www.upi.edu" target="_blank" alt="Universitas"> Universitas</a></li>
                </ul> 
            </div>
  
          </div>
        </div>
      </div>
  
      <div class="container d-md-flex py-4">
  
        <div class="mr-md-auto text-center text-md-left">
          <div class="copyright">
             <strong><span>UPI Kampus Serang</span></strong> @ 2020
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/presento-bootstrap-corporate-template/ -->
            
          </div>
        </div>
    </footer><!-- End Footer -->
    </main>
    <script src="http://kd-serang.upi.edu/assets/vendor/jquery/jquery.min.js"></script>
  <script src="http://kd-serang.upi.edu/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="http://kd-serang.upi.edu/assets/js/main.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

  </body>
    
 
</html>

