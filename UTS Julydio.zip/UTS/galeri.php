<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Download</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/headers/">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/cover/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="container">
      <header class="d-flex flex-wrap justify-content-center py-3 mb-4">
        <a href="SIK.html" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
          <img src="http://kd-serang.upi.edu/assets/img/logo.png" class="img-fluid" width="120" alt=""> </img>
          <span class="fs-4"></span><b>Sistem Informasi Kelautan</b></span>
        </a>
  
        <ul class="nav nav-pills">
            <li class="nav-item"><a href="#" class="nav-link">Beranda</a></li>
            <div class="dropdown">
              <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" style="color: blue">
                Profil
              </button>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="">Sejarah</a></li>
                <li><a class="dropdown-item" href="#">Visi Misi</a></li>
                <li><a class="dropdown-item" href="#">Struktur Organisasi</a></li>
                <li><a class="dropdown-item" href="#">Dosen</a></li>
              </ul>
            </div>
          <li class="nav-item"><a href="#" class="nav-link">Akademik</a></li>
          <li class="nav-item"><a href="akreditasi.html" class="nav-link">Akreditasi</a></li>
          <li class="nav-item"><a href="download.html" class="nav-link">Download</a></li>
          <li class="nav-item"><a href="#" class="nav-link">FAQ</a></li>
        </ul>
    </div>
      </header>
      <div style="background-image:url('images/library.jpeg');">
        <h2 style="text-align: center;">Download</h2>
        <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
          <div class="col d-flex align-items-start">
            <div class="icon-square bg-light text-dark flex-shrink-0 me-3">
              <svg class="bi" width="1em" height="1em"><use xlink:href="#toggles2"/></svg>
            </div>
            <div>
              <h2>Struktur Kurikulum</h2>
              <p>Program Studi Sistem Informasi Sistem Kelautan  merupakan bagian dari Ilmu Kelautan yang fokus pada analisis data kelautan baik numerik maupun spasial untuk kemudian diintegrasikan berbasis sistem informasi yang dikembangkan sebagai dasar pengambilan keputusan. Berdasarkan hal tersebut bidang kajian dari prodi SIK terdiri dari 5 bidang yaitu:</p>

                <p>Ilmu Kelautan </p>
                <p>Ilmu Perikanan</p>
                <p>Sistem Informasi</p>
                <p>Sistem Informasi Geografis</p>
                <p>Penginderaan Jauh Keluatan dan Ilmu Kelautan</p>
                <p>Sistem Informasi</p>
                
                Jumlah sks yang harus diambil oleh mahasiswa program studi sistem informasi kelautan adalah 146 sks dengan ketentuan:
                
                Mata Kuliah Umum (MKU) = 14 SKS
                Mata Kuliah Praktik Lapangan = 4 SKS
                Mata Kuliah Khusus Universitas = 2 SKS
                Mata Kuliah Khusus Fakultas (MKKF) = 6 SKS
                Mata Kuliah Keahlian Inti Program Studi (MKKIPS) = 102 SKS
                Mata Kuliah Keahlian Pilihan Program Studi (MKKPPS) = 18 SKS dengan mata kuliah pilihan yang ditawarkan sebanyak 31 SKS
              </p>
              
            </div>
          </div>
          <div class="col d-flex align-items-start">
            <div class="icon-square bg-light text-dark flex-shrink-0 me-3">
              <svg class="bi" width="1em" height="1em"><use xlink:href="#cpu-fill"/></svg>
            </div>
            <div>
              <h2>Dokumentasi</h2>
              <p>Paragraph of text beneath the heading to explain the heading. We'll add onto it with another sentence and probably just keep going until we run out of words.</p>
              <a href="#" class="btn btn-primary">
                Download
              </a>
            </div>
          </div>
          <div class="col d-flex align-items-start">
            <div class="icon-square bg-light text-dark flex-shrink-0 me-3">
              <svg class="bi" width="1em" height="1em"><use xlink:href="#tools"/></svg>
            </div>
            <div>
              <h2>Rencana Pembelajaran Semester</h2>
              <p>Paragraph of text beneath the heading to explain the heading. We'll add onto it with another sentence and probably just keep going until we run out of words.</p>
              <a href="#" class="btn btn-primary">
                Download
              </a>
            </div>
          </div>
        </div>
      </div>
</main>

  </body>
  <footer>
    <div class="container border-top">
      <p>&copy; Julydio Windu Nugroho (2008771)</p>
    </div>
  </footer>
 
</html>